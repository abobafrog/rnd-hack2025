import { Server as HTTPServer } from "http";
import { Server as SocketIOServer } from "socket.io";

export function initializeSocket(httpServer: HTTPServer) {
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("join-room", (roomCode: string, userName: string) => {
      socket.join(roomCode);
      socket.to(roomCode).emit("user-joined", { socketId: socket.id, userName });
      console.log(`${userName} joined room ${roomCode}`);
    });

    socket.on("offer", (roomCode: string, offer: RTCSessionDescriptionInit, targetSocketId: string) => {
      socket.to(targetSocketId).emit("offer", offer, socket.id);
    });

    socket.on("answer", (roomCode: string, answer: RTCSessionDescriptionInit, targetSocketId: string) => {
      socket.to(targetSocketId).emit("answer", answer, socket.id);
    });

    socket.on("ice-candidate", (roomCode: string, candidate: RTCIceCandidateInit, targetSocketId: string) => {
      socket.to(targetSocketId).emit("ice-candidate", candidate, socket.id);
    });

    socket.on("chat-message", (data: { roomCode: string, userName: string, message: string, timestamp: Date }) => {
      socket.to(data.roomCode).emit("chat-message", data);
      console.log(`Chat message in ${data.roomCode} from ${data.userName}: ${data.message}`);
    });

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
    });
  });

  return io;
}

