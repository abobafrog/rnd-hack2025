# PowerShell script to deploy Conference App to VPS using built-in SSH
Write-Host "=== Deploying Conference App to VPS ===" -ForegroundColor Green

# VPS details
$VPS_HOST = "138.124.14.203"
$VPS_USER = "root"
$VPS_PASS = "RNixIsjtRgJ0"
$APP_DIR = "/root/conference"

# Function to run SSH command
function Invoke-SSHCommand {
    param([string]$Command)
    
    $tempFile = [System.IO.Path]::GetTempFileName()
    $Command | Out-File -FilePath $tempFile -Encoding UTF8
    
    try {
        & ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=NUL $VPS_USER@$VPS_HOST "bash -s" < $tempFile
    }
    finally {
        Remove-Item $tempFile -Force
    }
}

# Function to copy files via SCP
function Copy-FilesToVPS {
    param([string]$LocalPath, [string]$RemotePath)
    
    Write-Host "Copying files from $LocalPath to $RemotePath..." -ForegroundColor Yellow
    
    # Create tar archive locally
    $archiveName = "app.tar.gz"
    & tar -czf $archiveName -C $LocalPath .
    
    if ($LASTEXITCODE -eq 0) {
        # Copy archive to VPS
        & scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=NUL $archiveName $VPS_USER@$VPS_HOST`:/tmp/
        
        if ($LASTEXITCODE -eq 0) {
            # Extract archive on VPS
            $extractCommand = @"
cd $RemotePath
tar -xzf /tmp/$archiveName
rm /tmp/$archiveName
"@
            Invoke-SSHCommand $extractCommand
        }
    }
    
    # Clean up local archive
    if (Test-Path $archiveName) {
        Remove-Item $archiveName -Force
    }
}

# Check if SSH is available
if (-not (Get-Command "ssh" -ErrorAction SilentlyContinue)) {
    Write-Host "SSH not found. Please install OpenSSH or use Windows Subsystem for Linux." -ForegroundColor Red
    Write-Host "You can install OpenSSH via: Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0" -ForegroundColor Yellow
    exit 1
}

# Stop existing application
Write-Host "Stopping existing application..." -ForegroundColor Yellow
$stopCommand = @"
cd $APP_DIR
pm2 stop conference-app 2>/dev/null || echo 'No existing app to stop'
"@
Invoke-SSHCommand $stopCommand

# Copy application files
Write-Host "Copying application files..." -ForegroundColor Yellow
Copy-FilesToVPS "." $APP_DIR

# Setup and start application on VPS
Write-Host "Setting up application on VPS..." -ForegroundColor Yellow
$deployCommands = @"
cd $APP_DIR

echo "Installing dependencies..."
npm install

echo "Installing PM2 globally if not installed..."
npm install -g pm2

echo "Creating logs directory..."
mkdir -p logs

echo "Running database migrations..."
npm run db:migrate || echo "Migrations failed, continuing..."

echo "Starting application with PM2..."
pm2 start ecosystem.config.js
pm2 save
pm2 startup

echo "Checking application status..."
pm2 status

echo "Application logs:"
pm2 logs conference-app --lines 10
"@

Invoke-SSHCommand $deployCommands

Write-Host "=== Deployment Complete ===" -ForegroundColor Green
Write-Host "Your application is now running on: http://$VPS_HOST:3000" -ForegroundColor Cyan
Write-Host ""
Write-Host "To check status: ssh $VPS_USER@$VPS_HOST 'cd $APP_DIR && pm2 status'" -ForegroundColor Yellow
Write-Host "To view logs: ssh $VPS_USER@$VPS_HOST 'cd $APP_DIR && pm2 logs conference-app'" -ForegroundColor Yellow
Write-Host "To restart: ssh $VPS_USER@$VPS_HOST 'cd $APP_DIR && pm2 restart conference-app'" -ForegroundColor Yellow
