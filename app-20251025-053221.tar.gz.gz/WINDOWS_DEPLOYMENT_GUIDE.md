# Manual Deployment Guide for Windows

## Prerequisites
You need SSH access to your VPS. Since built-in SSH tools aren't working, you can use one of these options:

### Option 1: Download PuTTY (Recommended)
1. Download PuTTY from: https://www.putty.org/
2. Install PuTTY (includes plink.exe and pscp.exe)
3. Add PuTTY to your PATH or use full paths

### Option 2: Use Git Bash (if Git is installed)
Git Bash includes SSH tools that work on Windows.

### Option 3: Use Windows Terminal with WSL
1. Install WSL: `wsl --install`
2. Install Ubuntu: `wsl --install -d Ubuntu`
3. Use SSH from within WSL

## Deployment Steps

### Step 1: Prepare Files
All necessary files are already in your project:
- `ecosystem.config.js` - PM2 configuration
- `deploy-to-vps.ps1` - PowerShell deployment script
- `deploy-to-vps.sh` - Bash deployment script

### Step 2: Connect to VPS
```bash
ssh root@138.124.14.203
# Password: RNixIsjtRgJ0
```

### Step 3: Prepare VPS Environment
```bash
# Update system
apt update && apt upgrade -y

# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt-get install -y nodejs

# Install MySQL client
apt-get install -y mysql-client

# Install PM2 globally
npm install -g pm2

# Create application directory
mkdir -p /root/conference
cd /root/conference
```

### Step 4: Upload Application Files
From your Windows machine, upload files using one of these methods:

#### Method A: Using PuTTY's pscp
```powershell
pscp -r -pw RNixIsjtRgJ0 . root@138.124.14.203:/root/conference/
```

#### Method B: Using Git Bash scp
```bash
scp -r . root@138.124.14.203:/root/conference/
```

#### Method C: Using WinSCP (GUI)
1. Download WinSCP from https://winscp.net/
2. Connect to 138.124.14.203 with root/RNixIsjtRgJ0
3. Upload all files to /root/conference/

### Step 5: Setup Database
```bash
# Create database
mysql -h localhost -u root -pRNixIsjtRgJ0 -e "CREATE DATABASE IF NOT EXISTS conference_db;"

# Run migrations
cd /root/conference
npm install
npm run db:migrate
```

### Step 6: Start Application
```bash
# Create logs directory
mkdir -p logs

# Start with PM2
pm2 start ecosystem.config.js
pm2 save
pm2 startup

# Check status
pm2 status
pm2 logs conference-app
```

### Step 7: Access Application
Your application will be available at:
- http://138.124.14.203:3000

## Management Commands
```bash
# Check status
pm2 status

# View logs
pm2 logs conference-app

# Restart application
pm2 restart conference-app

# Stop application
pm2 stop conference-app

# Monitor in real-time
pm2 monit
```

## Troubleshooting
1. Check if port 3000 is open in firewall
2. Verify database connection
3. Check PM2 logs for errors
4. Ensure all dependencies are installed

## Alternative: Use the PowerShell Script
If you install PuTTY, you can run:
```powershell
powershell -ExecutionPolicy Bypass -File deploy-to-vps.ps1
```
