import { useEffect, useRef, useState } from "react";
import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
// import { useAuth } from "@/_core/hooks/useAuth";
import { io, Socket } from "socket.io-client";

export default function Room() {
  const [, params] = useRoute("/room/:code");
  const roomCode = params?.code || "";
  
  // const { user } = useAuth();
  const user = null; // Временно отключаем аутентификацию
  const [userName, setUserName] = useState("");
  const [joined, setJoined] = useState(false);
  const [message, setMessage] = useState("");
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [remotePeers, setRemotePeers] = useState<Map<string, { stream: MediaStream, userName: string }>>(new Map());
  const [localMessages, setLocalMessages] = useState<Array<{id: string, userName: string, message: string, timestamp: Date}>>([]);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const socketRef = useRef<Socket | null>(null);
  const peerConnectionsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  
  const roomQuery = trpc.room.get.useQuery({ roomCode }, { 
    enabled: !!roomCode,
    retry: false,
    refetchOnWindowFocus: false
  });
  const joinMutation = trpc.room.join.useMutation();
  const sendMessageMutation = trpc.chat.send.useMutation();
  const messagesQuery = trpc.chat.messages.useQuery(
    { roomId: roomQuery.data?.id || 0 },
    { enabled: !!roomQuery.data?.id && joined, refetchInterval: 2000 }
  );

  // Демо-режим: если API недоступен, используем локальные данные
  const isDemoMode = roomQuery.error && roomCode;
  const demoRoom = isDemoMode ? { 
    id: 1, 
    name: `Демо комната ${roomCode}`, 
    roomCode,
    ownerId: 1 
  } : roomQuery.data;

  const configuration: RTCConfiguration = {
    iceServers: [
      { urls: "stun:stun.l.google.com:19302" },
      { urls: "stun:stun1.l.google.com:19302" },
    ]
  };

  // Все хуки должны быть перед условными возвратами
  useEffect(() => {
    if (!joined) return;

    const socket = io(window.location.origin);
    socketRef.current = socket;

    socket.on("connect", () => {
      console.log("Connected to socket server");
      socket.emit("join-room", roomCode, userName);
    });

    socket.on("user-joined", async ({ socketId, userName: remoteUserName }: { socketId: string, userName: string }) => {
      console.log("User joined:", socketId, remoteUserName);
      
      if (localStream) {
        await createPeerConnection(socketId, remoteUserName, true);
      }
    });

    socket.on("offer", async (offer: RTCSessionDescriptionInit, fromSocketId: string) => {
      console.log("Received offer from:", fromSocketId);
      const pc = await createPeerConnection(fromSocketId, "Remote User", false);
      await pc.setRemoteDescription(new RTCSessionDescription(offer));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      socket.emit("answer", roomCode, answer, fromSocketId);
    });

    socket.on("answer", async (answer: RTCSessionDescriptionInit, fromSocketId: string) => {
      console.log("Received answer from:", fromSocketId);
      const pc = peerConnectionsRef.current.get(fromSocketId);
      if (pc) {
        await pc.setRemoteDescription(new RTCSessionDescription(answer));
      }
    });

    socket.on("ice-candidate", async (candidate: RTCIceCandidateInit, fromSocketId: string) => {
      console.log("Received ICE candidate from:", fromSocketId);
      const pc = peerConnectionsRef.current.get(fromSocketId);
      if (pc) {
        await pc.addIceCandidate(new RTCIceCandidate(candidate));
      }
    });

    socket.on("chat-message", (data: { userName: string, message: string, timestamp: Date }) => {
      console.log("Received chat message:", data);
      const newMessage = {
        id: Date.now().toString(),
        userName: data.userName,
        message: data.message,
        timestamp: new Date(data.timestamp)
      };
      setLocalMessages(prev => [...prev, newMessage]);
    });

    return () => {
      socket.disconnect();
      peerConnectionsRef.current.forEach(pc => pc.close());
      peerConnectionsRef.current.clear();
    };
  }, [joined, roomCode, userName, localStream]);

  // Второй useEffect для получения медиа-потока
  useEffect(() => {
    if (joined && localVideoRef.current && !localStream) {
      navigator.mediaDevices.getUserMedia({ video: true, audio: true })
        .then(stream => {
          setLocalStream(stream);
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
        })
        .catch(err => console.error("Error accessing media devices:", err));
    }
  }, [joined, localStream]);

  // Условные возвраты после всех хуков
  if (roomQuery.isLoading && !isDemoMode) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Загрузка...</p>
        </div>
      </div>
    );
  }

  if (!demoRoom && !isDemoMode) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Комната не найдена</h1>
          <p className="text-gray-600">Проверьте правильность ссылки</p>
        </div>
      </div>
    );
  }

  const createPeerConnection = async (socketId: string, remoteUserName: string, isInitiator: boolean): Promise<RTCPeerConnection> => {
    const pc = new RTCPeerConnection(configuration);
    peerConnectionsRef.current.set(socketId, pc);

    if (localStream) {
      localStream.getTracks().forEach(track => {
        pc.addTrack(track, localStream);
      });
    }

    pc.ontrack = (event) => {
      console.log("Received remote track from:", socketId);
      setRemotePeers(prev => {
        const newMap = new Map(prev);
        newMap.set(socketId, { stream: event.streams[0], userName: remoteUserName });
        return newMap;
      });
    };

    pc.onicecandidate = (event) => {
      if (event.candidate && socketRef.current) {
        socketRef.current.emit("ice-candidate", roomCode, event.candidate, socketId);
      }
    };

    if (isInitiator) {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      if (socketRef.current) {
        socketRef.current.emit("offer", roomCode, offer, socketId);
      }
    }

    return pc;
  };

  const handleJoin = async () => {
    if (!userName.trim()) return;
    
    if (isDemoMode) {
      // Демо-режим: просто входим в комнату
      setJoined(true);
      return;
    }
    
    if (!roomQuery.data) return;
    
    try {
      await joinMutation.mutateAsync({
        roomCode,
        userName,
        userId: user?.id || 0,
      });
      setJoined(true);
    } catch (error) {
      console.error("Failed to join room:", error);
      // Fallback в демо-режим
      setJoined(true);
    }
  };

  const handleSendMessage = async () => {
    if (!message.trim()) return;
    
    // Добавляем сообщение в локальный чат
    const newMessage = {
      id: Date.now().toString(),
      userName: userName,
      message: message.trim(),
      timestamp: new Date()
    };
    
    setLocalMessages(prev => [...prev, newMessage]);
    
    // Отправляем через Socket.io для других участников
    if (socketRef.current) {
      socketRef.current.emit("chat-message", {
        roomCode,
        userName: userName,
        message: message.trim(),
        timestamp: newMessage.timestamp
      });
    }
    
    setMessage("");
  };

  const toggleAudio = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = !audioEnabled;
      });
      setAudioEnabled(!audioEnabled);
    }
  };

  const toggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach(track => {
        track.enabled = !videoEnabled;
      });
      setVideoEnabled(!videoEnabled);
    }
  };

  if (!joined) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-96 p-8 space-y-6">
          <div className="text-center">
            <h2 className="text-xl font-medium text-gray-900 mb-2">Присоединиться к встрече</h2>
            <p className="text-gray-600 text-sm">{demoRoom.name}</p>
            {isDemoMode && (
              <span className="inline-block mt-2 text-xs bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full font-medium">
                ДЕМО РЕЖИМ
              </span>
            )}
          </div>
          
          <div className="space-y-4">
            <Input
              type="text"
              placeholder="Введите ваше имя"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleJoin()}
            />
            <Button 
              onClick={handleJoin} 
              className="w-full"
              disabled={!userName.trim()}
            >
              Присоединиться
            </Button>
          </div>
          
          <div className="text-center text-sm text-gray-500">
            <p>Код комнаты: <span className="font-mono font-bold">{roomCode}</span></p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-semibold text-gray-900">{demoRoom.name}</h1>
              {isDemoMode && (
                <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full font-medium">
                  ДЕМО РЕЖИМ
                </span>
              )}
            </div>
            <div className="text-sm text-gray-500">
              Код: <span className="font-mono font-bold">{roomCode}</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Video Grid */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm p-4">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Видео</h2>
              <div className="grid grid-cols-2 gap-4">
                {/* Local Video */}
                <div className="relative">
                  <video
                    ref={localVideoRef}
                    autoPlay
                    muted
                    playsInline
                    className="w-full h-48 bg-gray-900 rounded-lg object-cover"
                  />
                  <div className="absolute bottom-2 left-2 bg-black bg-opacity-70 text-white px-2 py-1 rounded text-xs">
                    {userName} (Вы)
                  </div>
                  <div className="absolute top-2 right-2 flex space-x-1">
                    {!audioEnabled && (
                      <div className="bg-red-500 text-white p-1 rounded text-xs">🔇</div>
                    )}
                    {!videoEnabled && (
                      <div className="bg-red-500 text-white p-1 rounded text-xs">📹</div>
                    )}
                  </div>
                </div>

                {/* Remote Videos */}
                {Array.from(remotePeers.entries()).map(([socketId, peer]) => (
                  <div key={socketId} className="relative">
                    <video
                      autoPlay
                      playsInline
                      className="w-full h-48 bg-gray-900 rounded-lg object-cover"
                      ref={(videoEl) => {
                        if (videoEl && peer.stream) {
                          videoEl.srcObject = peer.stream;
                        }
                      }}
                    />
                    <div className="absolute bottom-2 left-2 bg-black bg-opacity-70 text-white px-2 py-1 rounded text-xs">
                      {peer.userName}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Chat */}
          <div className="bg-white rounded-lg shadow-sm p-4">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Чат</h2>
            
            {/* Messages */}
            <div className="h-64 overflow-y-auto space-y-2 mb-4">
              {localMessages.length === 0 ? (
                <div className="text-center text-gray-500 text-sm py-8">
                  Пока нет сообщений
                </div>
              ) : (
                localMessages.map((msg) => (
                  <div key={msg.id} className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-blue-600 text-xs">
                        {msg.userName}
                      </span>
                      <span className="text-xs text-gray-400">
                        {msg.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-gray-900 text-sm">{msg.message}</p>
                  </div>
                ))
              )}
            </div>
            
            {/* Message Input */}
            <div className="flex space-x-2">
              <Input
                type="text"
                placeholder="Написать сообщение..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                className="flex-1"
              />
              <Button onClick={handleSendMessage}>
                Отправить
              </Button>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="bg-white rounded-lg shadow-sm p-4 mt-4">
          <div className="flex items-center justify-center space-x-4">
            <Button
              onClick={toggleAudio}
              variant={audioEnabled ? "default" : "destructive"}
            >
              {audioEnabled ? "🔊 Микрофон" : "🔇 Микрофон"}
            </Button>
            
            <Button
              onClick={toggleVideo}
              variant={videoEnabled ? "default" : "destructive"}
            >
              {videoEnabled ? "📹 Камера" : "📹 Камера"}
            </Button>
            
            <Button
              variant="destructive"
              onClick={() => window.location.href = '/'}
            >
              Покинуть встречу
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

