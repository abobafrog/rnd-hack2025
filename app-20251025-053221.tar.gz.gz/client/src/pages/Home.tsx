import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { APP_TITLE } from "@/const";
import { useLocation } from "wouter";
import Auth from "@/components/Auth";
import { Video, Plus, LogOut, User } from "lucide-react";

export default function Home() {
  const [user, setUser] = useState<{id: string, name: string, email: string} | null>(null);
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Проверяем, есть ли сохраненный пользователь
    const savedUser = localStorage.getItem("conference_user");
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleAuth = (userData: {id: string, name: string, email: string}) => {
    setUser(userData);
  };

  if (!user) {
    return <Auth onAuth={handleAuth} />;
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Video className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-medium text-gray-900 mb-2">{APP_TITLE}</h1>
          <p className="text-gray-600 text-sm">Добро пожаловать, {user.name}!</p>
        </div>

        {/* Main Actions */}
        <Card className="shadow-lg">
          <CardContent className="p-6 space-y-4">
            <Button
              onClick={() => setLocation("/create")}
              className="w-full py-3 text-base font-medium bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="w-5 h-5 mr-2" />
              Создать встречу
            </Button>
            
            <div className="flex space-x-3">
              <Button
                onClick={() => {
                  localStorage.removeItem("conference_user");
                  setUser(null);
                }}
                variant="outline"
                className="flex-1"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Выйти
              </Button>
              
              <Button
                variant="outline"
                className="flex-1"
              >
                <User className="w-4 h-4 mr-2" />
                Профиль
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Quick Info */}
        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">
            Создавайте встречи и общайтесь в реальном времени
          </p>
        </div>
      </div>
    </div>
  );
}
