import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Video, 
  ArrowLeft, 
  Users, 
  Clock, 
  Settings,
  Copy,
  Share2,
  Calendar,
  Lock
} from "lucide-react";

export default function CreateRoom() {
  const [roomName, setRoomName] = useState("");
  const [isPrivate, setIsPrivate] = useState(false);
  const [, setLocation] = useLocation();
  const createRoomMutation = trpc.room.create.useMutation();

  const handleCreate = async () => {
    if (!roomName.trim()) return;

    try {
      const result = await createRoomMutation.mutateAsync({ name: roomName });
      setLocation(`/room/${result.roomCode}`);
    } catch (error) {
      console.error("Failed to create room:", error);
      // Для демонстрации создаем комнату локально
      const demoRoomCode = Math.random().toString(36).substring(2, 10);
      setLocation(`/room/${demoRoomCode}`);
    }
  };

  const copyRoomCode = () => {
    // В реальном приложении здесь будет код созданной комнаты
    navigator.clipboard.writeText("demo-room-code");
  };

  const shareRoom = () => {
    if (navigator.share) {
      navigator.share({
        title: roomName || 'Conference Room',
        text: `Присоединяйтесь к встрече: ${roomName}`,
        url: window.location.href,
      });
    } else {
      copyRoomCode();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center space-x-4">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setLocation("/")}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Назад
            </Button>
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <Video className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Создать встречу</h1>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Form */}
          <div className="lg:col-span-2">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Video className="w-6 h-6 text-blue-600" />
                  <span>Настройки встречи</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">
                    Название встречи
                  </label>
                  <Input
                    type="text"
                    placeholder="Введите название встречи"
                    value={roomName}
                    onChange={(e) => setRoomName(e.target.value)}
                    className="text-lg py-3"
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Lock className="w-5 h-5 text-gray-600" />
                      <div>
                        <p className="font-medium text-gray-900">Приватная встреча</p>
                        <p className="text-sm text-gray-500">
                          Только участники с кодом смогут присоединиться
                        </p>
                      </div>
                    </div>
                    <Button
                      variant={isPrivate ? "default" : "outline"}
                      size="sm"
                      onClick={() => setIsPrivate(!isPrivate)}
                    >
                      {isPrivate ? "Включено" : "Выключено"}
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Users className="w-5 h-5 text-gray-600" />
                      <div>
                        <p className="font-medium text-gray-900">Максимум участников</p>
                        <p className="text-sm text-gray-500">
                          До 100 участников одновременно
                        </p>
                      </div>
                    </div>
                    <span className="text-sm font-medium text-gray-600">100</span>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Clock className="w-5 h-5 text-gray-600" />
                      <div>
                        <p className="font-medium text-gray-900">Продолжительность</p>
                        <p className="text-sm text-gray-500">
                          Без ограничений по времени
                        </p>
                      </div>
                    </div>
                    <span className="text-sm font-medium text-gray-600">∞</span>
                  </div>
                </div>

                <div className="flex space-x-4 pt-4">
                  <Button 
                    onClick={handleCreate}
                    className="flex-1 py-3 text-lg font-semibold"
                    disabled={createRoomMutation.isPending || !roomName.trim()}
                  >
                    {createRoomMutation.isPending ? "Создание..." : "Создать встречу"}
                  </Button>
                  
                  <Button 
                    variant="outline"
                    onClick={() => setLocation("/")}
                    className="px-6"
                  >
                    Отмена
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Preview & Actions */}
          <div className="space-y-6">
            {/* Preview */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="w-6 h-6 text-gray-600" />
                  <span>Предварительный просмотр</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Video className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">
                        {roomName || "Новая встреча"}
                      </p>
                      <p className="text-sm text-gray-500">
                        {isPrivate ? "Приватная" : "Публичная"}
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Участники:</span>
                      <span className="font-medium">0/100</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Статус:</span>
                      <span className="font-medium text-green-600">Готова к запуску</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Быстрые действия</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <Copy className="w-4 h-4 mr-2" />
                  Скопировать код
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Share2 className="w-4 h-4 mr-2" />
                  Поделиться ссылкой
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Calendar className="w-4 h-4 mr-2" />
                  Запланировать
                </Button>
              </CardContent>
            </Card>

            {/* Tips */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Советы</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm font-medium text-blue-900">💡 Совет</p>
                  <p className="text-sm text-blue-700">
                    Дайте встрече понятное название для легкого поиска
                  </p>
                </div>
                
                <div className="p-3 bg-green-50 rounded-lg">
                  <p className="text-sm font-medium text-green-900">🔒 Безопасность</p>
                  <p className="text-sm text-green-700">
                    Используйте приватные встречи для конфиденциальных обсуждений
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

