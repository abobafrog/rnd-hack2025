# PowerShell script using .NET SSH capabilities
Write-Host "=== Deploying Conference App to VPS ===" -ForegroundColor Green

# VPS details
$VPS_HOST = "138.124.14.203"
$VPS_USER = "root"
$VPS_PASS = "RNixIsjtRgJ0"
$APP_DIR = "/root/conference"

# Function to execute SSH commands using .NET
function Invoke-SSHCommand {
    param([string]$Command)
    
    try {
        # Create a temporary script file
        $tempScript = [System.IO.Path]::GetTempFileName() + ".sh"
        $Command | Out-File -FilePath $tempScript -Encoding UTF8
        
        # Use PowerShell's Invoke-Expression with SSH
        $sshCommand = "ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=NUL $VPS_USER@$VPS_HOST 'bash -s' < `"$tempScript`""
        
        Write-Host "Executing: $Command" -ForegroundColor Yellow
        Invoke-Expression $sshCommand
        
        # Clean up
        Remove-Item $tempScript -Force -ErrorAction SilentlyContinue
    }
    catch {
        Write-Host "Error executing SSH command: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Function to copy files using tar and scp
function Copy-FilesToVPS {
    param([string]$LocalPath, [string]$RemotePath)
    
    Write-Host "Copying files from $LocalPath to $RemotePath..." -ForegroundColor Yellow
    
    try {
        # Create tar archive
        $archiveName = "app-$(Get-Date -Format 'yyyyMMdd-HHmmss').tar.gz"
        
        # Use PowerShell to create tar archive
        $files = Get-ChildItem -Path $LocalPath -Recurse | Where-Object { 
            $_.FullName -notlike "*node_modules*" -and 
            $_.FullName -notlike "*.git*" -and
            $_.FullName -notlike "*dist*" -and
            $_.FullName -notlike "*logs*"
        }
        
        # Create archive using 7-Zip if available, otherwise use tar
        if (Get-Command "7z" -ErrorAction SilentlyContinue) {
            $files | ForEach-Object { 
                if ($_.PSIsContainer) {
                    & 7z a -ttar $archiveName $_.FullName
                } else {
                    & 7z a -ttar $archiveName $_.FullName
                }
            }
            & 7z a -tgzip "$archiveName.gz" $archiveName
            Remove-Item $archiveName -Force
            $archiveName = "$archiveName.gz"
        } else {
            # Fallback: create a simple file list and copy individually
            Write-Host "Creating file package..." -ForegroundColor Yellow
            
            # Create a temporary directory for packaging
            $tempDir = [System.IO.Path]::GetTempPath() + "deploy-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
            New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
            
            # Copy essential files
            $essentialFiles = @(
                "package.json", "package-lock.json", "pnpm-lock.yaml",
                "tsconfig.json", "vite.config.ts", "vitest.config.ts",
                "drizzle.config.ts", "ecosystem.config.js",
                "server", "client", "shared", "drizzle"
            )
            
            foreach ($file in $essentialFiles) {
                if (Test-Path $file) {
                    if ((Get-Item $file).PSIsContainer) {
                        Copy-Item -Path $file -Destination $tempDir -Recurse -Force
                    } else {
                        Copy-Item -Path $file -Destination $tempDir -Force
                    }
                }
            }
            
            # Create archive
            Compress-Archive -Path "$tempDir\*" -DestinationPath $archiveName -Force
            
            # Clean up temp directory
            Remove-Item $tempDir -Recurse -Force
        }
        
        if (Test-Path $archiveName) {
            # Copy archive to VPS
            $scpCommand = "scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=NUL `"$archiveName`" $VPS_USER@$VPS_HOST`:/tmp/"
            Invoke-Expression $scpCommand
            
            if ($LASTEXITCODE -eq 0) {
                # Extract archive on VPS
                $extractCommand = @"
cd $RemotePath
tar -xzf /tmp/$archiveName
rm /tmp/$archiveName
chmod +x ecosystem.config.js
"@
                Invoke-SSHCommand $extractCommand
            }
            
            # Clean up local archive
            Remove-Item $archiveName -Force -ErrorAction SilentlyContinue
        }
    }
    catch {
        Write-Host "Error copying files: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Check if SSH is available
if (-not (Get-Command "ssh" -ErrorAction SilentlyContinue)) {
    Write-Host "SSH not found. Please install OpenSSH or use one of these alternatives:" -ForegroundColor Red
    Write-Host "1. Install Git for Windows (includes SSH tools)" -ForegroundColor Yellow
    Write-Host "2. Install PuTTY" -ForegroundColor Yellow
    Write-Host "3. Use WSL: wsl --install" -ForegroundColor Yellow
    Write-Host "4. Use WinSCP for file transfer and manual deployment" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Manual deployment instructions are available in WINDOWS_DEPLOYMENT_GUIDE.md" -ForegroundColor Cyan
    exit 1
}

# Stop existing application
Write-Host "Stopping existing application..." -ForegroundColor Yellow
$stopCommand = @"
cd $APP_DIR 2>/dev/null && pm2 stop conference-app 2>/dev/null || echo 'No existing app to stop'
"@
Invoke-SSHCommand $stopCommand

# Copy application files
Write-Host "Copying application files..." -ForegroundColor Yellow
Copy-FilesToVPS "." $APP_DIR

# Setup and start application on VPS
Write-Host "Setting up application on VPS..." -ForegroundColor Yellow
$deployCommands = @"
cd $APP_DIR

echo "Installing dependencies..."
npm install

echo "Installing PM2 globally if not installed..."
npm install -g pm2

echo "Creating logs directory..."
mkdir -p logs

echo "Running database migrations..."
npm run db:migrate || echo "Migrations failed, continuing..."

echo "Starting application with PM2..."
pm2 start ecosystem.config.js
pm2 save
pm2 startup

echo "Checking application status..."
pm2 status

echo "Application logs:"
pm2 logs conference-app --lines 10
"@

Invoke-SSHCommand $deployCommands

Write-Host "=== Deployment Complete ===" -ForegroundColor Green
Write-Host "Your application is now running on: http://$VPS_HOST:3000" -ForegroundColor Cyan
Write-Host ""
Write-Host "To check status: ssh $VPS_USER@$VPS_HOST 'cd $APP_DIR && pm2 status'" -ForegroundColor Yellow
Write-Host "To view logs: ssh $VPS_USER@$VPS_HOST 'cd $APP_DIR && pm2 logs conference-app'" -ForegroundColor Yellow
Write-Host "To restart: ssh $VPS_USER@$VPS_HOST 'cd $APP_DIR && pm2 restart conference-app'" -ForegroundColor Yellow
